import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StudDelete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory s=new Configuration().configure().buildSessionFactory();
		Session sobj = s.openSession();
		
		sobj.beginTransaction();
		Student st = sobj.get(Student.class, 8);
		sobj.delete(st);
		System.out.println("Data deleted Successfully...!");
		sobj.getTransaction().commit();
		sobj.close();
	}

}
