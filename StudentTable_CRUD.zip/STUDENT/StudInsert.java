import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StudInsert {
	 public static void main(String[] args) 
	 {
	 

	  SessionFactory s=new Configuration().configure().buildSessionFactory();
		Session sobj = s.openSession();
		
		sobj.beginTransaction();
		for(int i=1; i<=10; i++)
		{
			 Student stud = new Student();
			  stud.setStudentName("Dinesh Rajput"+i);
			  stud.setCourse("MCA"+i);
			  stud. setAddress("pune"+i);
			  sobj.save(stud);
			  
		}
		System.out.println("Inserted Successfully...!");
		sobj.getTransaction().commit();
		sobj.close();

}
}
