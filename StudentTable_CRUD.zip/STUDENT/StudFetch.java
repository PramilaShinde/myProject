import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StudFetch {
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		SessionFactory s=new Configuration().configure().buildSessionFactory();
		Session sobj = s.openSession();
		
		sobj.beginTransaction();
		Student st= sobj.get(Student.class, 5);
		System.out.println("Roll Number: "+st. getAddress()+", Student Name: "+st.getStudentName()+", Course: "+st.getCourse());
		System.out.println("Data Read Successfully...!");
		sobj.getTransaction().commit();
		sobj.close();

	}

}

