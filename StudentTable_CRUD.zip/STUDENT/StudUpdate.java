import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StudUpdate {
	public static void main(String[] args) 
	{
		SessionFactory s=new Configuration().configure().buildSessionFactory();
		Session sobj = s.openSession();
		
		sobj.beginTransaction();
		// TODO Auto-generated method stub
		
	Student sd=	sobj.get(Student.class, 7);
	sd.setStudentName("Pranitee");
	sd.setCourse("advocate");
	sd. setAddress("TilakRoad");
	sobj.update(sd);
	System.out.println("Data Updated Successfully...!");
	sobj.getTransaction().commit();
	sobj.close();
	}	

	}

